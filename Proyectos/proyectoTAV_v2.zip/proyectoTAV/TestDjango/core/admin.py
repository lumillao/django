from django.contrib import admin
from .models import Categoria, Vehiculo

admin.site.register(Categoria)
admin.site.register(Vehiculo)

# Register your models here.
